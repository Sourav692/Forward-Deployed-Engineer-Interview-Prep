# Current System: Enterprise AI Platform


Version: `v0.10-stage-10`. Previous: `v0.9-stage-09`. Decision: [ADR-010](decisions/ADR-010-governed-model-customisation.md).

Add approved dataset snapshots, Fine-Tuning Jobs, experiment/checkpoint records, Evaluation Service and Model Registry. Training completion creates a candidate, never a live route. Preserve current identity/resource policy, audit, egress, versioned retrieval/cache, durable operation identity, unknown-outcome handling, fair budgets, and Stage 8/9 release/serving contracts.

The executed slice validates in-memory dataset/job/checkpoint/report/approval metadata and a deterministic gate worksheet. No training, model inference, optimiser recovery, deployed registry, identity service, or prior-runtime integration is claimed. Stage 11 inherits these lifecycle roles and all earlier runtime boundaries.

Latest guide: [Stage 10](../stages/10-fine-tuning/guide.md). Evidence: [validation](../stages/10-fine-tuning/validation.md). Learner mastery remains unassessed.
