# ADR-009: Approved Inference Routes With Explicit Memory and Outcome Limits

Status: accepted educational architecture. Stage: 9. Date: 2026-11-02. Supersedes: none; preserve ADR-001–008 authority, evidence, identity and recovery contracts.

## Situation and Alternatives

Hosted serving cost, data-path constraints and latency motivate comparing self-hosted inference for the supplier workflow. Compare an approved hosted route, a single-device replica, multiple replicas and supported tensor/pipeline sharding. Choose a logical Model Gateway that selects approved bundle/profile before dispatch and preserves stable durable operation identity. Self-hosting remains an evaluated option, not an automatically deployed substitute.

## Decision

Validate verified identity/current source policy/audit, trusted private-ready provider profile, model context/output envelope and shared request/token/slot budgets. User flags cannot downgrade the private-route requirement in this fixture. New calls require a fresh grant. Completed same-key replay keeps original bundle/result and revalidates all original evidence; a partly revoked original source set cannot be replaced by a new allowed subset to reveal the old answer.

Unknown transport outcomes and incomplete dispatch/result writes remain inspectable, with conservative reservations and no automatic alternate-provider call. Final saved success follows result commit. Release pointer changes affect future operations, not prior facts. Budget, dispatch, commit and settlement remain separate transactions and need explicit production reconciliation.

## Evidence and Depth Boundaries

The Gateway composes actual prior Security, Gate and Releases fixtures with injected transport. Twelve tests check approved/denied routes, readiness/private/provider constraints, model envelopes, budget-before-transport, stable replay across release changes, current/partial revocation, conflict, memory arithmetic and final-save failure without retry. No network privacy, actual inference, tokeniser, model/GPU, cluster or benchmark is run.

The memory worksheet assumes an 8B dense model, 32 layers, 8 KV heads, head dimension 128, FP16 KV and a four-GiB runtime reserve. It separates raw weight bits from KV precision and estimates peak active context. Fit does not prove speed, quality, isolation or real allocation success. GPU optimisation/sharding/placement topics remain D1; serving/orchestration exercise is D2; Gateway is the D3 implementation slice.

## Operations and Next Boundary

Profile exact approved model/engine/hardware under representative token/concurrency distribution; observe queue/prefill/decode, TTFT/ITL, memory, readiness/drain, usage and unknown effects. Pin image/model IDs and keep approved egress/secret policy. Stop at Stage 9; Stage 10 may add justified customisation without weakening these serving and release constraints.
