# Current System: Enterprise AI Platform


Version: `v0.11-stage-11`. Previous: `v0.10-stage-10`. Decision: [ADR-011](decisions/ADR-011-residency-aware-regional-cells.md).

Retain all runtime and Stage 10 lineage controls. Add trusted tenant placement, EU-primary and EU-secondary for A/B, US-home for C, data-class replication, regional private/provider profiles, recovery eligibility and usage reconciliation. Current policy, audit, the current approved generation, ready artifacts and capacity remain mandatory for promotion. Async result copies may lose acknowledged operation evidence within the stated RPO, measured as verified lag at isolation; hold the uncertain interval rather than blindly redispatch.

Authority placement clarifies the accepted cell design; ADR-011 is unchanged. Tenant A/B policy, membership, model approval/withdrawal, release-bundle generation, alias bindings and writer-ownership records live in an EU-only authority store, consensus-replicated across EU-primary, EU-secondary and a small EU witness location. Losing EU-primary leaves a 2-of-3 quorum in the EU. Tenant C has the equivalent store in its US-home cell, and no authority record leaves its tenant's region. Writer ownership is a quorum lease with a monotonically increasing epoch, the fencing token. The regional database, object store, job workers and the Model Gateway's billable-usage write path reject any write carrying an older epoch. Promotion requires a new lease from the quorum and proof that the old epoch is rejected; reachability or a health check is never fencing. If the quorum is lost, nothing is promoted, no protected disclosure is made, and the platform reports authority unavailable. The global control plane holds only opaque placement and is never authority.

Usage evidence is keyed by tenant, operation and attempt: a redelivered attempt counts once, a retry in another region is extra spend, and a conflicting revision of an attempt is rejected. Cost per success divides all attempt spend plus fixed cost by successful workflows.

The executed slices are a pure recovery eligibility/capacity/unit-cost worksheet and an in-memory attempt-keyed usage ledger. No cloud region, network, replication, consensus store, actual lease or epoch enforcement, provider billing integration, or load measurement is claimed. Stage 12 inherits the regional cells, the EU authority quorum placement and lineage architecture with these explicit production gaps.


Latest guide: [Stage 11](../stages/11-multi-region/guide.md). Evidence: [validation](../stages/11-multi-region/validation.md). Learner mastery remains unassessed.
