# ADR-012: Versioned Regional Platform Contracts and Controlled Adoption

Status: accepted educational architecture, not production approval. Stage: 12. Date: 2026-11-02. Supersedes: none; prior runtime decisions remain in force.

## Situation

Four hypothetical teams copy supplier configuration and release logic, creating inconsistent regional/model gates. [Stage 11](../../stages/11-multi-region/guide.md) already defines regional cells and recovery constraints. Centralisation must preserve them and the runtime contracts from ADR-001–010.

## Options Considered

| Option | Benefit | Cost/risk | Decision |
| --- | --- | --- | --- |
| Library/templates only | Quick initial adoption | Version drift; policy duplicated in apps | Use for SDK/schema, not sole enforcement |
| Versioned contracts and regional platform services | Shared enforcement and supported workflow | Compatibility, platform dependency and support burden | Choose logical target using existing roles |
| One global request service | Concentrated management | Residency coupling and global blast radius | Reject |
| Full microservice rewrite | Independent operations where needed | New network/transaction boundaries and risky migration | Defer until measured need |

## Decision

Add an application manifest and control plane for desired state, plus a durable migration controller. Keep customer execution in approved regional cells. Platform owns contract enforcement, app teams own task behaviour and outcomes, security/data owners own current purpose/access, and SRE/database owners own recovery authority. Use a named decision owner and record dissent and revisit triggers.

Inventory first, validate manifests, shadow only eligible read-only work, pilot one app/cell, switch one authoritative route with generation checking, and expand only after outcome/cost agreement. Recheck current eligibility for both cutover and rollback. Never restore revoked policy, old source visibility, uncertain external effects, or an incompatible schema through routing rollback.

## Guarantees and Non-Guarantees

SQLite tests establish durable scoped proposal identity, conflict rejection, trusted shadow metadata, a deterministic sample gate, atomic route/previous/generation updates, injected rollback before commit, restart inspection, stale-update rejection, and currently eligible reversal. This is migration metadata only. It does not execute customer work, attest comparison evidence, enforce production identity, deploy services, migrate schemas/data, fence remote writers, or integrate previous runtime fixtures. Eligibility flags represent trusted external decisions.

## Economics and Operational Checks

At the guide's illustrative assumptions, 600 migration hours cost $60,000, net monthly savings are $4,000, break-even is 15 months, and three-year savings are $84,000. An extra 40 support hours/month removes operating savings. Track adoption friction, blocked changes, stale generations, pilot outcomes, support hours, regional capacity, and actual cost per successful workflow. Read [validation](../../stages/12-staff-platform/validation.md) before interpreting local test evidence.

## Revisit Trigger

Revisit when pilot support burden removes the business case, measured regional enforcement fails, a contract cannot evolve compatibly, a team needs proven independent scaling/ownership, or customer requirements change durability/geography. Production approval requires real integration and measured operating evidence. Research specialisations remain deferred.
