# Current System: Enterprise AI Platform

**Architecture version:** `v0.1-stage-01`  
**Latest authored stage:** [Stage 1: Build the MVP](../stages/01-mvp/guide.md)  
**Decision:** [ADR-001](decisions/ADR-001-synchronous-mvp.md)  
**Acceptance:** educational architecture baseline, not production deployment approval

The Stage 1 teaching revision adds five learning phases, beginner intuition, intermediate checkpoints, explicit coverage, and a request lifecycle walkthrough. It retains architecture `v0.1-stage-01` and ADR-001; no architecture decision is replaced. The local API now explicitly validates JSON media type, encoded body size, prompt length, and operation-key input.

## Before

No system or prior stage existed in this workspace. Customer, workload, latency, quota, and retention requirements are hypothetical and explicitly labelled in the stage guide.

## Current Components

| Component | Responsibility | Evidence and boundary |
| --- | --- | --- |
| Client / Enterprise User | Alice in Tenant A asks for and reopens a supplier-email draft | API consumer in the local exercise; no production UI |
| AI App Service / API Gateway ingress role | Validate input, orchestrate request, enforce commit-before-success | Real local HTTP handler |
| Identity/Policy Service role | Derive trusted tenant/user; enforce scoped access | Public local fixture tokens; real identity provider is not integrated |
| Model Gateway adapter role | Bound and normalise hosted generation | Deterministic success/timeout stub; no hosted API calls |
| Metadata DB | Persist processing/completed/failed state, answer, owner, and request key | SQLite file; short transactions and compound history index |
| Telemetry role | Request outcomes/durations, provider attempts, storage failures, stale state | Proposed metadata-only contract; no production exporter |
| Hosted model | External generation dependency | Design boundary only; stubbed in executable |

All application roles live in one process. The SQLite database file is local to the application host. No Queue, Workers, Search Index, Evaluation Service, GPU Pool, or Fine-Tuning Jobs exist.

## Request and Security Invariants

1. Derive identity and tenant in trusted code. Reject invalid identity before request storage or model generation.
2. Scope history by both `tenant_id` and `user_id`; caller body fields cannot override identity.
3. Commit `processing`, invoke the model, commit final state, then acknowledge. Never hold a write transaction across generation.
4. A new successful completion is `201`; completed duplicate replay is `200`. Processing/failed/conflicting duplicate keys return `409` without another provider call.
5. A saved provider timeout returns `504`. A storage error returns `503`; a previous processing row may remain. Unknown provider outcomes must not be silently retried.
6. Use HTTPS and protected provider credentials in deployment. The loopback lab uses HTTP and public fixture tokens only.

## Workload and Open Limits

Illustrative demand is 200 requests/workday, a brief 0.5 requests/second peak, and expected 1,200 input plus 300 output tokens/request. The representative healthy path is 2,620 ms with a four-second provider deadline. These are planning assumptions, not measured performance. The p95 target below five seconds needs a real workload test.

The executable has no external identity/provider integration, enforced wall-clock provider deadline, retention sweeper, scheduled reconciliation, network gateway, distributed transaction, automated backup, or production monitoring. A final storage failure or crash can leave a processing row. Learner mastery and production readiness are not asserted.

## Next Stage Starting Point

A future Stage 2 may introduce durable jobs, a Queue, and Workers when long-running processing blocks interactive requests or must survive a worker failure. It must preserve tenant scope, request history, model adapter boundary, and documented duplicate/acknowledgement semantics or explicitly migrate them. Stage 2 has not been authored here.

See [validation](../stages/01-mvp/validation.md) for executed checks and limitations, and [coverage status](../progress/coverage-status.csv) for actual authored coverage.
