# Enterprise AI Platform Learning Workspace

Stage 1 is the only authored stage. Its hypothetical customer is Alice in Tenant A, drafting a supplier email from text she supplies. Later-stage curriculum entries describe planned teaching, not completed lessons.

## Read and Practise

Open the [offline HTML guide](stages/01-mvp/guide.html) directly in a browser, or read the [Markdown guide](stages/01-mvp/guide.md). The five learning phases preserve the technical material while adding beginner intuition, three answer-before-reveal checkpoints, and a six-step request walkthrough. The HTML embeds its fonts, diagrams, and scripts and needs no server or network.

The executable exercise requires Python 3.10 or newer with SQLite support. It makes no hosted-model calls and uses public local identity fixtures. From the directory containing `10_AI_System_Design/`, run:

```bash
python3 10_AI_System_Design/stages/01-mvp/labs/test_mvp.py
```

To explore the HTTP API, use the commands in the guide. Keep the fixture server on loopback; real identity, TLS, hosted generation, and production latency are separate, unchecked integrations.

## Inspect the Supporting Artifacts

- [Stage plan](stages/01-mvp/stage-plan.md) and [stage state](stages/01-mvp/stage-state.json)
- [Current architecture](architecture/current-system.md) and [ADR-001](architecture/decisions/ADR-001-synchronous-mvp.md)
- [Actual coverage](progress/coverage-status.csv) and [curriculum map](progress/curriculum-map.json)
- [Verification results and limitations](stages/01-mvp/validation.md)

Six modules are taught at their mapped depth. Modules 1.3, 2.3, and 13.1 are context only; their first-teaching stages remain 12, 6, and 6 respectively. Other modules are deferred. All learner completion remains unassessed.

## Verify a Distributed Copy

The repository's `dist/stage-01-mvp.zip` preserves this workspace root and its supporting files. After extracting into an empty directory, rerun the Python tests above. To audit the archive itself from the repository root, run:

```bash
python3 10_AI_System_Design/stages/01-mvp/labs/verify_package.py 10_AI_System_Design/dist/stage-01-mvp.zip
```

That verifier extracts into a temporary directory, checks declared artifacts and local links, and runs the HTTP tests. The archive excludes itself, databases, credentials, caches, and render captures. Passed fixture tests verify the learning slice, not production readiness or learner mastery.
