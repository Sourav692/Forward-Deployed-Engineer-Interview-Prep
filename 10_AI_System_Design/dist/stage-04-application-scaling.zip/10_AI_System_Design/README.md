# Enterprise AI Platform Learning Workspace

Stages 1 through 4 are authored and locally checked. Workload figures are illustrative; learner mastery and production readiness remain unassessed.

- Stage 1: [Build the MVP](stages/01-mvp/guide.html), [Markdown](stages/01-mvp/guide.md), [validation](stages/01-mvp/validation.md).
- Stage 2: [Distributed Execution](stages/02-distributed-execution/guide.html), [Markdown](stages/02-distributed-execution/guide.md), [validation](stages/02-distributed-execution/validation.md).
- Stage 3: [Enterprise Knowledge](stages/03-enterprise-knowledge/guide.html), [Markdown](stages/03-enterprise-knowledge/guide.md), [validation](stages/03-enterprise-knowledge/validation.md).
- Stage 4: [Scale the Application](stages/04-application-scaling/guide.html), [Markdown](stages/04-application-scaling/guide.md), [validation](stages/04-application-scaling/validation.md).

Open any HTML directly in a browser: fonts, diagrams, and interactions are embedded. Python labs require Python 3.10+ with SQLite; JavaScript simulator checks additionally require Node. Run the commands in each guide. The dist archives preserve supporting files and prerequisite lessons. Production integrations and load testing are not implied by local tests.
